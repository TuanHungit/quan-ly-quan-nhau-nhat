package com.hns2t.QuanLyQuanNhau_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyQuanNhauServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
